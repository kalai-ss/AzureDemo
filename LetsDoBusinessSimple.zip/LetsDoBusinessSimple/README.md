# LDBS Backend

This is the backend for the LDBS project.
LDBS-backend/
│
├── src/
│   ├── config/
│   │   └── index.js
│   │
│   ├── controllers/
│   │   ├── authController.js
│   │
│   ├── middleware/
│   │   ├── authMiddleware.js
│   │   └── errorMiddleware.js
│   ├── routes/
│   │   ├── authRoutes.js
│   │
│   ├── services/
│   │   ├── authService.js
│   │
│   ├── utils/
│   │   └── apiError.js
│   │
│   └── index.js
│
├── prisma/
│   ├── schema.prisma
│   └── .env
│
├── .gitignore
├── package.json
└── README.md