const express = require('express');
const userController = require('../controllers/userController');
const { authenticateJWT } = require('../middleware/authMiddleware');
const router = express.Router();
const upload = require('../middleware/uploadMiddleware');
// ...
router.get('/all', userController.getAllUsers);
router.get('/', userController.getUser);
router.get('/profile/:id', userController.getUserProfile);
router.put('/', userController.updateUser);
router.post('/picture', upload.single('file'), userController.uploadPicture);
router.get('/picture', userController.getProfilePicture);
// router.delete('/', userController.deleteUser);
router.post('/reset-password', userController.resetPassword);
// router.post('/request-email-verification', userController.requestEmailVerification);
router.post('/profile-picture', authenticateJWT, userController.uploadProfilePicture);
router.get('/stats/:userId', userController.getUserWithStats);
router.delete('/profile-picture/:id', userController.deleteProfilePicture);
module.exports = router;
