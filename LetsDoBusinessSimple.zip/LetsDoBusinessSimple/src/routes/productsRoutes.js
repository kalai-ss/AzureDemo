const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

// GET 
router.get('', productController.getAllProducts);

// POST 
router.post('', productController.createProduct);

// PUT /:id
router.put('/:id', productController.updateProduct);

// DELETE /:id
router.delete('/:id', productController.deleteProduct);

module.exports = router;
