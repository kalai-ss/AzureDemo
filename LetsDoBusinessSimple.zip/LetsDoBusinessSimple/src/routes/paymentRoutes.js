
const express = require('express');
const { createMessage, getAllMessages, getMessageById, updateMessage, deleteMessage } = require('../controllers/messageController');
const bookingController = require('../controllers/bookingController');
const router = express.Router();
const stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);

router.post('/create-checkout-session', async (req, res) => {
    try {
        const session = await stripe.checkout.sessions.create({
          line_items: [
            {
              // Provide the exact Price ID (for example, pr_1234) of the product you want to sell
              price: 'price_1NbSCvFRoG19KianRzSClFcY',
              quantity: 1,
            },
          ],
          mode: 'payment',
          success_url: `http://localhost:9000/payment?success=true`,
          cancel_url: `http://localhost:9000/payment?canceled=true`,
        });
      
        res.redirect(303, session.url);
        
    } catch (error) {
        console.log(error);
    }
  });

module.exports = router;

 