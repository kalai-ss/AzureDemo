const express = require('express');
const router = express.Router();
const subCategoryController = require('../controllers/subCategoryController');

// Get all subCategories
router.get('/', subCategoryController.getAllSubCategories);

// Get a specific subCategory by ID
router.get('/:id', subCategoryController.getSubCategoryById);

// Create a new subCategory
router.post('/', subCategoryController.createSubCategory);

// Update a subCategory by ID
router.put('/:id', subCategoryController.updateSubCategory);

// Delete a subCategory by ID
router.delete('/:id', subCategoryController.deleteSubCategory);

module.exports = router;
