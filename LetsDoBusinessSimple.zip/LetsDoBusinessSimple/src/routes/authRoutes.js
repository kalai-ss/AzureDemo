const express = require('express');
const authController = require('../controllers/authController');

const router = express.Router();

router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/verify-email/:token', authController.verifyEmail);
router.post('/password/reset', authController.requestPasswordReset);
router.put('/password/reset/:token', authController.resetPasswordWithToken);
router.get('/password/reset/:token', authController.verifyPasswordResetToken);

module.exports = router;
