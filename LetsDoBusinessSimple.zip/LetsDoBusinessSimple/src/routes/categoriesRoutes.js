const express = require('express');
const router = express.Router();
const categoryController = require('../controllers/categoryController');

// GET /categories
router.get('', categoryController.getAllCategories);

// GET /categories/:id
router.get('/:id', categoryController.getCategoryById);

// POST /categories
router.post('', categoryController.createCategory);

// PUT /categories/:id
router.put('/:id', categoryController.updateCategory);

// DELETE /categories/:id
router.delete('/:id', categoryController.deleteCategory);

module.exports = router;
