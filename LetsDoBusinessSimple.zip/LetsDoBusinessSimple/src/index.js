const express = require('express');
const helmet = require('helmet');
const morgan = require('morgan');
const cors = require('cors');
const dotenv = require('dotenv');
const socketIO = require('socket.io');
const http = require('http');
const expressStaticGzip = require('express-static-gzip');
const history = require('express-history-api-fallback');
const path = require('path');
// Import routes
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const categoriesRoutes = require('./routes/categoriesRoutes');
const subcategoriesRoutes = require('./routes/subcategoriesRoutes');
const productRoutes = require('./routes/productsRoutes');

const { authenticateJWT, protectedRoutes } = require('./middleware/authMiddleware');

// Load environment variables from .env file
dotenv.config();

// Create Express app
const app = express();


// Middleware
// Secure HTTP headers

app.use(
  helmet.contentSecurityPolicy({
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "blob:"],
      workerSrc: ["'self'", "blob:"], // Permet le service-worker.js
      connectSrc: ["'self'", "https://api.mapbox.com", "https://events.mapbox.com"],
      // autres directives ici
    },
  })
);

app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(express.json()); // Parse JSON request body
app.use(express.urlencoded({ extended: true })); // Parse JSON request body
app.use(morgan('combined')); // Request logging

// app.use('/api/equipments', equipmentRouter);

protectedRoutes.forEach((route) => {
  console.log("protected route : ", route);
  app.use(route, authenticateJWT);
});
// Routes
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/categories', categoriesRoutes);
app.use('/api/subcategories', subcategoriesRoutes);
app.use('/api/products', productRoutes );


if (process.env.NODE_ENV === 'development') {
  console.log("public folder served on dev mode ");
  app.use('/api/service-worker.js' ,express.static(path.resolve(__dirname, '../../my-heroes-cmp', 'src' , 'service-worker.js')));
} 




if (process.env.NODE_ENV === 'production') {
  app.use(expressStaticGzip(path.resolve(__dirname, '../../my-heroes-cmp', 'dist')));
  app.use(history(path.resolve(__dirname, '../../my-heroes-cmp', 'dist', 'index.html')));
}
// Catch-all route for 404 errors
app.use(function (err, req, res, next) {
  if (process.env.NODE_ENV !== 'production') {
    res.status(502).send(err.message);
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
const PORT_SOCKET = process.env.PORT_SOCKET || 4000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});


