const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { PrismaClient, TokenType, ServiceStatus } = require('@prisma/client');
const prisma = new PrismaClient();
const { sendFormatedTemplate } = require('../utils/template');
const authService = require('../services/authService');
const { v4: uuidv4 } = require('uuid');

const generateToken = (userId) => {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN,
  });
};

const hashPassword = async (password) => {
  const salt = await bcrypt.genSalt(10);
  return await bcrypt.hash(password, salt);
};

const comparePassword = async (password, hashedPassword) => {
  return await bcrypt.compare(password, hashedPassword);
};

const register = async ({ phone, email, password, firstName, lastName, role = "CUSTOMER" }) => {

  const hashedPassword = await hashPassword(password);
  const newUser = await prisma.user.create({
    data: {
      email: email.toLowerCase().trim(),
      firstName,
      lastName,
      password: hashedPassword,
      role,
      phone
    },
  });
  /// creer un hero 

  // Envoyer un e-mail de bienvenue
  /// create token and save it in db

  ///get setup by key and element value and replace it in template
  const token = await createEmailVerificationToken(email);

  const setup = [
    { key: '#firstName#', value: firstName },
    { key: '#verificationUrl#', value: encodeURI(process.env.CLIENT_URL + '/signin/verification/email/' + token) },
  ];

  const content = await sendFormatedTemplate('welcome', setup, email, 'Bienvenue à bord !');
  delete newUser.password;
  return newUser;
};

const login = async ({ email, password }) => {
  const user = await getUserByEmail(email);
  if (!user) {
    throw new Error('Invalid email or password');
  }

  const isMatch = await comparePassword(password, user.password);
  if (!isMatch) {
    throw new Error('Invalid email or password');
  }
  const token = jwt.sign({
    id: user.id,
    email: user.email,
    firstName: user.firstName,
    lastName: user.lastName,
    role: user.role,
    emailVerified: user.emailVerified
  }, process.env.JWT_SECRET);

  return {
    user: {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
    },
    token,
  };
};

const getUserByEmail = async (email) => {
  return await prisma.user.findUnique({
    where: {
      email : email.toLowerCase().trim()
    },
  });
};


// ...
const createEmailVerificationToken = async (email) => {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    throw new Error(404, '404 my hero', 'User 404 my hero');
  }
  /// date timestamp plus 1h
  const expires = Date.now() + 3600000 * 12; // 12 hour
  const token = uuidv4();

  // Stockez le token dans la base de données pour vérification ultérieure
  await prisma.token.create({
    data: { token, userId: user.id, name: TokenType.EMAIL_VERIFICATION },
  });

  return token;
};
const createPasswordResetToken = async (email) => {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    throw new Error(202, 'No user found with this email address');
  }
  /// date timestamp plus 1h
  const expires = Date.now() + 3600000; // 1 hour
  const token = uuidv4()  
  // Stockez le token dans la base de données pour vérification ultérieure
  await prisma.token.create({
    data: { token, userId: user.id, name: TokenType.PASSWORD_RESET},
  });

  return {user, token};
};

// verifyEmail
const verifyEmail = async (token) => {
  /// get user by token from model Token

  const _token = await checkToken(token, "emailVerification");

  /// verify token time and user

  
  if (!_token) {
    throw new Error(404, '404 my hero', 'User 404 my hero');
  } else {
    await prisma.user.update({
      where: { id: _token.user.id },
      data: { emailVerified: true },
    });
  }
  return _token;
};

/// verifyPasswordResetToken by decrypting the token
const verifyPasswordResetToken = async (token) => {
  /// decrypt token
  /// get user by token from model Token
  const _token = await checkToken(token, "passwordReset");
  

};


const checkToken = async (token, name) => {
  
  const tokenRecord = await prisma.token.findUnique({
    where: {
      token: token,
    },
    include: {
      user: true,
    },
  });

  if (!tokenRecord) {
    throw new Error('Token invalid ');
  }

  return tokenRecord;

};

// resetPasswordWithToken
const resetPasswordWithToken = async (token, newPassword) => {
  const tokenRecord = await prisma.token.findUnique({
    where: {
      token: token,
      name: TokenType.PASSWORD_RESET
    },
    include: {
      user: true,
    },
  });

  if (!tokenRecord) {
    throw new Error('Token 404 my hero');
  }

  const hashedPassword = await bcrypt.hash(newPassword, 10);
  const user = await prisma.user.update({
    where: { id: tokenRecord.userId },
    data: { password: hashedPassword },
  });

  await prisma.token.delete({
    where: {
      token: token,
    },
  });
  return user.id;
};





//parrainnage
// Function to sponsor a user
const sponsorUser = async (heroToken, userId) => {
  try {
    // Check if the user exists
    const userExists = await prisma.user.findUnique({ where: { id: userId } });
    if (!userExists) {
      throw new Error('User not found');
    }

    // Check if the hero exists
    const heroExists = await prisma.hero.findUnique({ where: { id: heroId } });
    if (!heroExists) {
      throw new Error('Hero not found');
    }

    // Associate the user with the hero by updating the heroId field in the User table
    const sponsoredUser = await prisma.user.update({
      where: { id: userId },
      data: { referentId: heroId },
    });

    return sponsoredUser;
  } catch (error) {
    throw new Error(`Unable to sponsor the user: ${error.message}`);
  }
};



module.exports = {
  generateToken,
  hashPassword,
  comparePassword,
  getUserByEmail,
  login,
  register,
  createPasswordResetToken,
  resetPasswordWithToken,
  checkToken,
  verifyPasswordResetToken,
  verifyEmail,
  sponsorUser
};
