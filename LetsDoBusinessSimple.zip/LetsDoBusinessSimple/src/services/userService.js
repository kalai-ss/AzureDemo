const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const fs = require('fs');

exports.createUser = async (user = {
  email: 'example@example.com',
  password: 'password',
  firstName: 'John',
  lastName: 'Doe',
}) => {
  const newUser = await prisma.user.create({
    data: user,
  });

  console.log('New user created:', newUser);
}
// ...

exports.getUser = async (id) => {
  const user = await prisma.user.findUnique({
    where: { id }, include: {
      hero: {
        include: {
          subcategories: {
            include: {
              subcategory: true,
            },
          },
          bookings: true,
        },
      },
      client: true,
    },
  });
  delete user.password;
  delete user.passwordResetToken;
  return user;
};
exports.getUserProfile = async (id) => {
  const user = await prisma.user.findUnique({
    where: {
      id
    }, include: {
      hero: {
        include: {
          subcategories: {
            include: {
              subcategory: true,
            },
          },
          BookingHero: true,
        },
      },
      client: {
        include: {
          bookings: {
            include: {
              reviews: {
                include: {
                  booking: true,
                  User: {
                    include: {
                      image: true,
                    },
                  },
                },
              },
              BookingHero: true,
            }
          },
        },
      },

      image: true,
      reviews: {
        include: {
          booking: true,
          User: {
            include: {
              image: true,
            },
          },
        },
      },
    },
  });
  delete user.password;
  delete user.passwordResetToken;
  /// get user picture 
  const image = user.image[0];
  let picture = fs.readFileSync(image.url, { encoding: 'base64' });
  picture = 'data:' + image.mimetype + ';base64,' + picture;

  return {user, picture};
};


exports.updateUser = async (id, updatedData) => {
  const updatedUser = await prisma.user.update({
    where: { id },
    data: updatedData,
  });
  return updatedUser;
};

exports.deleteUser = async (id) => {
  const deletedUser = await prisma.user.delete({
    where: { id },
  });
  return deletedUser;
};

exports.resetPassword = async (email, newPassword) => {
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) {
    throw new Error(404, '404 my hero', 'User 404 my hero');
  }

  const hashedPassword = await bcrypt.hash(newPassword, 10);
  await prisma.user.update({
    where: { id: user.id },
    data: { password: hashedPassword },
  });
};

exports.getUserByToken = async (token) => {
  const tokenRecord = await prisma.token.findUnique({
    where: {
      token: token,
    },
    include: {
      user: true,
    },
  });

  if (!tokenRecord) {
    throw new Error('Token 404 my hero');
  }

  return tokenRecord.user;
}
exports.getAllUsers = async () => {
  const usersWithHeroesAndSkills = await prisma.user.findMany({
    include: {
      hero: {
        include: {
          subcategories: {
            include: {
              subcategory: true,
            },
          },
        },
      },
      client: true,
    },
  });

  return usersWithHeroesAndSkills;
};


// exports.uploadProfilePicture = async (userId) => {
//   try {

//     const user = await prisma.user.update({
//       where: { id: parseInt(userId) },
//       data: { profilePictureUrl },
//     });

//     return user;
//   } catch (error) {
//     console.log(error);
//   }
// };

// exports.deleteProfilePicture = async (userId) => {
//   try {


//     const user = await prisma.user.update({
//       where: { id: parseInt(userId) },
//       data: { profilePictureUrl: null },
//     });

//     return user;
//   } catch (error) {
//     next(error);
// console.log(error);
//   }
// }
