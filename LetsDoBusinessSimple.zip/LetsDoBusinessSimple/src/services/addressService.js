
const { PrismaClient } = require('@prisma/client');
const { reverseGeocode, forwardGeocode } = require('../utils/address');
const prisma = new PrismaClient();

exports.createAddressForUser = async (req, res) => {
    const { address, city, country, zipCode, userId, longitude, latitude } = req.body;
    const newAdress = await prisma.address.create({
        data: {
            address,
            city,
            country,
            zipCode,
            longitude,
            latitude,
            userId: parseInt(userId),
        },
    });
    res.status(201).json(newAdress);
}
exports.locatedAddress = async (bookingData) => {
    if (bookingData.address) {
        const { address } = bookingData;
        const { longitude, latitude } = await forwardGeocode(address.full_address || address.place_name || address.street);
        bookingData.address.longitude = longitude;
        bookingData.address.latitude = latitude;


    }
    else if (bookingData.longitude && bookingData.latitude) {
        const { longitude, latitude } = bookingData;
        const address = await reverseGeocode({ latitude, longitude });
        const street = address.find((a) => a.properties.feature_type === "address")?.properties
        const city = address.find((a) => a.properties.feature_type === "place").properties
        const country = address.find((a) => a.properties.feature_type === "country").properties
        const postcode = address.find((a) => a.properties.feature_type === "postcode").properties
        bookingData.address = {}
        bookingData.address.street = street.name
        bookingData.address.city = city.name
        bookingData.address.postcode = postcode.name
        bookingData.address.country = country.name
        bookingData.address.latitude = latitude
        bookingData.address.longitude = longitude


    } else {
        throw new Error(400, "Bad Request", "Missing address or coordinates");
    }
    return bookingData
}
exports.manageAddressForBooking = async (bookingData, mode = 'save') => {

    const { address, ...booking } = await this.locatedAddress(bookingData)
    const {
        address_number: number,
        street,
        city,
        country,
        postcode,
        longitude,
        latitude,
        full_address,
        place_name,
        place,
        address_level2,
        id
    } = address;


    const bookingAddressFormatted = {
        number,
        street: street || full_address || place_name,
        city: place || address_level2 || city,
        country,
        postcode,
        longitude: Number(longitude),
        latitude: Number(latitude)
    }

    let newAddress;
    if (mode === 'save') {
        newAdress = await prisma.address.create({
            data: {
                ...bookingAddressFormatted,
                bookingId: parseInt(booking.id),
            }
        });
    }
    if (mode === 'update') {
        newAdress = await prisma.address.update({
            where: { id: parseInt(address.id) },
            data: {
                ...bookingAddressFormatted,
            }

        });
        await prisma.booking.update({
            where: { id: parseInt(booking.id) },
            data: {
                longitude: Number(longitude),
                latitude: Number(latitude)
            }
        })
    }

    return newAdress;
}
exports.getAllAddress = async (req, res) => {
    const address = await prisma.address.findMany();
    res.status(200).json(address);
}
exports.getPostalAdress = async (req, res) => {
    const postalAdress = await prisma.address.findMany({
        where: {
            userId: parseInt(req.params.userId)
        }
    });
    res.status(200).json(postalAdress);
}

exports.getAddressById = async (req, res) => {
    const address = await prisma.address.findUnique({
        where: {
            id: parseInt(req.params.id)
        }
    });
    res.status(200).json(address);
}

exports.updateAddress = async (req, res) => {
    const { address, city, country, zipCode, userId } = req.body;
    const updatedAdress = await prisma.address.update({
        where: {
            id: parseInt(req.params.id)
        },
        data: {
            address,
            city,
            country,
            zipCode,
            userId: parseInt(userId),
        }
    });
    res.status(200).json(updatedAdress);
}

exports.deleteAddress = async (req, res) => {
    const deletedAdress = await prisma.address.delete({
        where: {
            id: parseInt(req.params.id)
        }
    });
    res.status(200).json(deletedAdress);
}

exports.getAddressByUserId = async (req, res) => {
    const address = await prisma.address.findMany({
        where: {
            userId: parseInt(req.params.userId)
        }
    });
    res.status(200).json(address);
}


exports.getAddressFromGeo = async (req, res) => {
    const address = await reverseGeocode(req.params.latitude, req.params.longitude)

    res.status(200).json(address);
}

exports.getGeoFromAdress = async (req, res) => {
    const geo = await forwardGeocode(req.params.address)

    res.status(200).json(geo);
}