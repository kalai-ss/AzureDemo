const { PrismaClient, TokenType, ServiceStatus } = require('@prisma/client');
const prisma = new PrismaClient();

/// code CRUD operations for the product service

exports.createProduct = async (data) => {
    try {
        const product = await prisma.product.create({
            data: {
                ...data,
            },
        });
        return product;
    } catch (error) {
        throw error;
    }
}

exports.getAllProducts = async () => {
    try {
        const products = await prisma.product.findMany();
        return products;
    } catch (error) {
        throw error;
    }
}

exports.getProductById = async (id) => {
    try {
        const product = await prisma.product.findUnique({
            where: {
                id: parseInt(id)
            }
        });
        return product;
    } catch (error) {
        throw error;
    }
}

exports.updateProduct = async (id, data) => {
    try {
        const product = await prisma.product.update({
            where: {
                id: parseInt(id)
            },
            data: {
                ...data,
            }
        });
        return product;
    } catch (error) {
        throw error;
    }
}

exports.deleteProduct = async (id) => {
    try {
        const product = await prisma.product.delete({
            where: {
                id: parseInt(id)
            }
        });
        return product;
    } catch (error) {
        throw error;
    }
}

exports.getProductByCategory = async (category) => {
    try {
        const products = await prisma.product.findMany({
            where: {
                category: category
            }
        });
        return products;
    } catch (error) {
        throw error;
    }
}

exports.getProductBy = async (where) => {
    try {
        const products = await prisma.product.findMany({
            where: where
        });
        return products;
    } catch (error) {
        throw error;
    }
}

