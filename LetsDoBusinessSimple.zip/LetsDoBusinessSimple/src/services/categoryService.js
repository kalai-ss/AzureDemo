const { PrismaClient, TokenType, ServiceStatus } = require('@prisma/client');
const prisma = new PrismaClient();

/// code CRUD operations for the category service

exports.createCategory = async (data) => {
    try {
        const category = await prisma.category.create({
            data: {
                ...data,
            },
        });
        return category;
    } catch (error) {
        throw error;
    }
}

exports.getAllCategories = async () => {
    try {
        const categories = await prisma.category.findMany();
        return categories;
    } catch (error) {
        throw error;
    }
}

exports.getCategoryById = async (id) => {
    try {
        const category = await prisma.category.findUnique({
            where: {
                id: parseInt(id)
            }
        });
        return category;
    } catch (error) {
        throw error;
    }
}

exports.updateCategory = async (id, data) => {
    try {
        const category = await prisma.category.update({
            where: {
                id: parseInt(id)
            },
            data: {
                ...data,
            }
        });
        return category;
    } catch (error) {
        throw error;
    }
}

exports.deleteCategory = async (id) => {
    try {
        const category = await prisma.category.delete({
            where: {
                id: parseInt(id)
            }
        });
        return category;
    } catch (error) {
        throw error;
    }
}

    