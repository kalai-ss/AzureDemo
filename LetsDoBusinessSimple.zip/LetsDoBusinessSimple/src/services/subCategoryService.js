const { PrismaClient, TokenType, ServiceStatus } = require('@prisma/client');
const prisma = new PrismaClient();

/// code CRUD operations for the subCategory service

exports.createSubCategory = async (data) => {
    try {
        const subCategory = await prisma.subCategory.create({
            data: {
                ...data,
            },
        });
        return subCategory;
    } catch (error) {
        throw error;
    }
}

exports.getAllSubCategories = async () => {
    try {
        const subCategories = await prisma.subCategory.findMany();
        return subCategories;
    } catch (error) {
        throw error;
    }
}

exports.getSubCategoryById = async (id) => {
    try {
        const subCategory = await prisma.subCategory.findUnique({
            where: {
                id: parseInt(id)
            }
        });
        return subCategory;
    } catch (error) {
        throw error;
    }
}

exports.updateSubCategory = async (id, data) => {
    try {
        const subCategory = await prisma.subCategory.update({
            where: {
                id: parseInt(id)
            },
            data: {
                ...data,
            }
        });
        return subCategory;
    } catch (error) {
        throw error;
    }
}

exports.deleteSubCategory = async (id) => {
    try {
        const subCategory = await prisma.subCategory.delete({
            where: {
                id: parseInt(id)
            }
        });
        return subCategory;
    } catch (error) {
        throw error;
    }
}

exports.getSubCategoryByCategoryId = async (id) => {
    try {
        const subCategories = await prisma.subCategory.findMany({
            where: {
                categoryId: parseInt(id)
            }
        });
        return subCategories;
    } catch (error) {
        throw error;
    }
}

exports.getSubCategoryByCategoryName = async (name) => {
    try {
        const subCategories = await prisma.subCategory.findMany({
            where: {
                category: {
                    name: name
                }
            }
        });
        return subCategories;
    } catch (error) {
        throw error;
    }
}

