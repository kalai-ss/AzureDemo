// Dans le fichier userService.js

const { PrismaClient, InvitationStatus } = require('@prisma/client');

const prisma = new PrismaClient();


// Dans le fichier heroService.js

exports.countConfirmedAndCompletedBookingsByHero = async (userId) => {
    const count = await prisma.bookingHero.count({
      where: {
        AND: [
          { userId },
          { bookingStatus: InvitationStatus.CONFIRMED },
          { booking: { status: ServiceStatus.COMPLETED } },
        ],
      },
    });
    return count;
  };
  
// Dans le fichier userService.js

// Dans le fichier heroService.js

exports.countPositiveReviewsForCompletedBookingsByHero = async (userId) => {
    const count = await prisma.review.count({
      where: {
        AND: [
          { reviewedUserId: userId },
          { rating: { gte: 4 } },
          { booking: { status: InvitationStatus.COMPLETED } },
        ],
      },
    });
    return count;
  };
  
  
  // Dans le fichier userService.js

exports.countOrganizedActivitiesByUser = async (userId) => {
    const count = await prisma.booking.count({
      where: {
        clientId: userId, status: InvitationStatus.COMPLETED},
    });
    return count;
  };

  
  // Dans le fichier userService.js

exports.getUserWithStats = async (userId) => {
    const user = await prisma.user.findUnique({
      where: { id: userId },
    });
  
    const reservationsCount = await countConfirmedAndCompletedBookingsByHero(userId);
    const positiveReviewsCount = await countPositiveReviewsForCompletedBookingsByHero(userId);
    const organizedActivitiesCount = await countOrganizedActivitiesByUser(userId);
  
    const userWithStats = {
      ...user,
      reservationsCount,
      positiveReviewsCount,
      organizedActivitiesCount,
    };
  
    return userWithStats;
  };
  
