

const fs = require('fs');
const path = require('path');
const { sendEmail } = require('../services/mailerService');

const getTemplate = async (templateName) => {
    const filePath = path.join(__dirname, `../templates/${templateName}.html`);
    let content = fs.readFileSync(filePath, { encoding: 'utf8' })
    return content;
}

const getFormatedTemplate = async (templateName, setup = []) => {

    let template = await getTemplate(templateName);

    setup.forEach((element) => {
        template = template.toString().replace(`"#${element.key}#`, element.value);
    });
    return template;
};
const sendFormatedTemplate = async (templateName, setup = [], to, subject) => {

    let template = await getTemplate(templateName);
    // for (s of setup) {
    //     template = template.replace(`#${s.key}#`, s.value);
    // }

    setup.forEach((element) => {
        template = template.toString().replaceAll(`${element.key}`, element.value);
    });

    await sendEmail({
        to,
        subject,
        html: template,
    });
    return template;
};

module.exports = { getFormatedTemplate, getTemplate, sendFormatedTemplate };