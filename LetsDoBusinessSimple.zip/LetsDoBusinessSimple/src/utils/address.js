const axios = require('axios');
const apiKey = process.env.MAPBOX_API_KEY;
const _ = require('lodash');
exports.forwardGeocode = async (address) => {


    try {
        const response = await axios.get(`https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(address)}.json?access_token=${process.env.MAPBOX_API_KEY}`);

        if (response.data.features.length > 0) {
            const coordinates = response.data.features[0]?.geometry.coordinates;
            const latitude = coordinates[1];
            const longitude = coordinates[0];
         
            return { latitude, longitude };
        } else {
            console.log('No results found');
            return null;
        }
    } catch (error) {
        console.error('Error:', error);
        throw new Error('Failed to perform forward geocoding');
    }
};

// Exemple d'utilisation
// forwardGeocode('Paris, France'); // Passer l'addresse réelle

exports.reverseGeocode = async ({latitude, longitude}) => {

    try {
        const response = await axios.get(`https://api.mapbox.com/search/geocode/v6/reverse?country=fr&language=fr&longitude=${String(longitude)}&latitude=${String(latitude)}&access_token=${process.env.MAPBOX_API_KEY}`);
        if (response.data.features.length > 0) {
            const address = await response.data.features
            return address;
        } else {
            console.log('No results found');
            return null;
        }
    } catch (error) {
        console.error('Error:', error);
        throw new Error('Failed to perform reverse geocoding');
    }
};

// Exemple d'utilisation
// reverseGeocode(48.8588443, 2.2943506); // Passer les coordonnées latitude et longitude réelles
