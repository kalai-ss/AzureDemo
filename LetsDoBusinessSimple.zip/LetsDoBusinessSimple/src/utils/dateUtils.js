const { format } = require('date-fns');

exports.formatDate = (date) => {
    return format(new Date(date), "dd/MM/yyyy 'à' HH:mm");
}
    