const { sendEmail } = require('../services/mailerService');
const { getFormatedTemplate } = require('../utils/template');

const emailTo = async (email, subject, templateName, setup) => {
    ///verify email i s array 
    if (Array.isArray(email)) {

        ///send each eamil
        email.forEach(async (mail) => {
            return sendEmail({
                to: mail,
                subject,
                html: await getFormatedTemplate(templateName, setup),
            });
        }
        )
    } else {
        return sendEmail({
            to: email,
            subject,
            html: await getFormatedTemplate(templateName, setup),
        });
    }


}
