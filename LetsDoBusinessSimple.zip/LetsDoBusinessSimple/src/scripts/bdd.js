const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const client = async () => {
    const bookings = await prisma.bookingHero.findFirst({
        where: {
            userId: 1,
            invitationStatus :"PENDING"
        },
        include: {
            booking: {
                include: {
                    messages: true
                }
            }
        }

    })
    console.log(bookings);
}


client()