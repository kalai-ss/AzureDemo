const clamav = require('node-clamav');
const cron = require('node-cron');

const scanDirectory = '/upload'; // Le dossier que vous voulez scanner

// Fonction pour scanner le dossier
function scanFiles() {
  clamav.scanDirectory(scanDirectory, (err, infectedFiles) => {
    if (err) {
      console.error('Error scanning directory:', err);
      return;
    }

    if (infectedFiles.length === 0) {
      console.log('No infected files found.');
    } else {
      console.error('Infected files found:', infectedFiles);
    }
  });
}

// Planifier la tâche pour qu'elle s'exécute toutes les 2 heures
cron.schedule('0 */2 * * *', scanFiles);

console.log('Cron job set to run every 2 hours.');
