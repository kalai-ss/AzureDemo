const multer = require('multer');
const fs = require('fs');
const path = require('path');
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const userDirPath = path.join(__dirname, `../../uploads/${req.user.id}/`);
    if (!fs.existsSync(userDirPath)) {
      fs.mkdirSync(userDirPath, { recursive: true }); // Crée le dossier s'il n'existe pas
    }
    cb(null, userDirPath);
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname); // Utilise le timestamp actuel pour éviter les conflits de noms de fichiers
  }
});

const upload = multer({
  storage: storage
  // limits: {
  //     fileSize: 5 * 1024 * 1024 // limite la taille du fichier à 5MB
  // },
  // fileFilter: function (req, file, cb) {
  //     const validTypes = /jpeg|jpg|png|gif/;
  //     const extName = validTypes.test(file.mimetype);
  //     const extNameValid = validTypes.test(
  //         path.extname(file.originalname).toLowerCase()
  //     );

  //     if (extName && extNameValid) {
  //         return cb(null, true);
  //     }

  //     cb("Erreur: seules les images au format jpeg, jpg, png, et gif sont autorisées!");
  // }
});
module.exports = upload;
