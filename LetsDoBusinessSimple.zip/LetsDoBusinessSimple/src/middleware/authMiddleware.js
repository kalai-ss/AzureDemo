const jwt = require('jsonwebtoken');
const { getUserByEmail } = require('../services/authService');

const authenticateJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;
  const url = req.originalUrl;
  if (authHeader) {
    const token = authHeader.split(' ')[1];
    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
      if (err) {
        console.log(err);
        console.log(url , "refusé");
        return next(new Error(403, 'Forbidden', err));
      }
      req.user = user;
      next();
    });
  } else {
    next(new Error(401, 'Unauthorized', 'Missing authentication token'));
  }
};

const adminAuthJWT = (req, res, next) => {
  const authHeader = req.headers.authorization;

  if (authHeader) {
    const token = authHeader.split(' ')[1];
    jwt.verify(token, process.env.JWT_SECRET, async (err, user) => {
      if (err) {
        console.log(err);
        return next(new Error(403, 'Forbidden', err));
      }

      const _user = await getUserByEmail(user.email);
      if (_user.role !== 'ADMIN') {
        return next(new Error(403, 'Forbidden', 'You are not an admin'));
      }
      req.user = user;
      next();
    });
  } else {
    next(new Error(401, 'Unauthorized', 'Missing authentication token'));
  }
};


const protectedRoutes = [
  '/api/users/*',
  "/api/user",
  // "/api/addresses/*",
  "/api/payment/*",

];
const adminRoutes = [
  '/api/admin/*',

];

module.exports = {
  authenticateJWT,
  protectedRoutes,
};