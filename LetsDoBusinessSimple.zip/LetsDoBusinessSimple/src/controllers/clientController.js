const clientService = require('../services/clientService');

exports.createClient = async (req, res, next) => {
    try {
        const client = await clientService.createClient(req.body);
        res.status(201).json(client);
    } catch (error) {
        next(error);
        console.log(error);
    }
}

exports.getAllClients = async (req, res, next) => {
    try {
        const clients = await clientService.getAllClients();
        res.status(200).json(clients);
    } catch (error) {
        next(error);
        console.log(error);
    }
}

exports.getClientById = async (req, res, next) => {
    try {
        const client = await clientService.getClientById(req.user.id);
        res.status(200).json(client);
    } catch (error) {
        next(error);
        console.log(error);
    }
}

exports.updateClient = async (req, res, next) => {
    try {
        const client = await clientService.updateClient(req.params.id, req.body);
        res.status(200).json(client);
    } catch (error) {
        next(error);
        console.log(error);
    }
}

exports.deleteClient = async (req, res, next) => {
    try {
        const client = await clientService.deleteClient(req.params.id);
        res.status(200).json(client);
    } catch (error) {
        next(error);
        console.log(error);
    }
}

exports.getClientByEmail = async (req, res, next) => {
    try {
        const client = await clientService.getClientByEmail(req.params.email);
        res.status(200).json(client);
    } catch (error) {
        next(error);
        console.log(error);
    }
}

