
const { PrismaClient } = require('@prisma/client');
const { reverseGeocode, forwardGeocode } = require('../utils/address');
const prisma = new PrismaClient();

exports.createAdress = async (req, res, next) => {
    try {
        const { address, city, country, zipCode, userId } = req.body;
        const newAdress = await prisma.address.create({
            data: {
                address,
                city,
                country,
                zipCode,
                userId: parseInt(userId),
            },
        });
        res.status(201).json(newAdress);
        
    } catch (error) {
        next(error)
    }
}
exports.getAllAdress = async (req, res, next) => {
    try {
        const address = await prisma.address.findMany();
        res.status(200).json(address);
        
    } catch (error) {
        next(error)
    }
}
exports.getPostalAdress = async (req, res, next) => {
    try {
        const postalAdress = await prisma.address.findMany({
            where: {
                userId: parseInt(req.params.userId)
            }
        });
        res.status(200).json(postalAdress);
        
    } catch (error) {
        next(error)
    }
}

exports.getAdressById = async (req, res, next)  => {
    try {
        const address = await prisma.address.findUnique({
            where: {
                id: parseInt(req.params.id)
            }
        });
        res.status(200).json(address);
        
    } catch (error) {
        next(error)
    }
}

exports.updateAdress = async (req, res, next) => {
    try {
        const { address, city, country, zipCode, userId } = req.body;
        const updatedAdress = await prisma.address.update({
            where: {
                id: parseInt(req.params.id)
            },
            data: {
                address,
                city,
                country,
                zipCode,
                userId: parseInt(userId),
            }
        });
        res.status(200).json(updatedAdress);
        
    } catch (error) {
        next(error)
    }
}

exports.deleteAdress = async (req, res, next) => {
    try {
        const deletedAdress = await prisma.address.delete({
            where: {
                id: parseInt(req.params.id)
            }
        });
        res.status(200).json(deletedAdress);
        
    } catch (error) {
        next(error)
    }
}

exports.getAdressByUserId = async (req, res , next) => {
    try {
        const address = await prisma.address.findMany({
            where: {
                userId: parseInt(req.params.userId)
            }
        });
        res.status(200).json(address);
        
    } catch (error) {
        next(error)
    }
}


exports.getAdressFromGeo = async (req, res , next) => {
    try {
      
        if (!req.query.latitude || !req.query.longitude) {
            throw new Error('latitude and longitude are required')
        }
        const address = await reverseGeocode({latitude : req.query.latitude, longitude : req.query.longitude})
        const info = {}
        const street = address.find((a) => a.properties.feature_type === "street" || a.properties.feature_type === "neighborhood")?.properties
        const city = address.find((a)=>a.properties.feature_type === "place")?.properties
        const country = address.find((a)=>a.properties.feature_type === "country")?.properties
        const postcode = address.find((a)=>a.properties.feature_type === "postcode")?.properties
        info.street = street?.name
        info.neighborhood = street?.name
        info.city = city?.name
        info.zipCode  = postcode?.name
        info.country = country?.name
        info.latitude = req.query.latitude
        info.longitude = req.query.longitude
  
        res.status(200).json(info);
    } catch (error) {
      
        next(error)
    }
}

exports.getGeoFromAdress = async (req, res, next) => {
    try {
        const geo = await forwardGeocode(req.params.address)
    
        res.status(200).json(geo);
        
    } catch (error) {
        next(error)
    }
}