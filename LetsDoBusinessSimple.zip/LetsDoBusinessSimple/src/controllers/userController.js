const userService = require('../services/userService');
const authService = require('../services/authService');
const mailService = require('../services/mailerService');
const { getUserWithStats } = require('../services/userStatService');
const { sendFormatedTemplate } = require('../utils/template');
// const { uploadProfilePicture, getProfilePicture } = require('../services/imageService');


exports.getUser = async (req, res, next) => {
  try {
    const user = await userService.getUser(req.user.id);
    res.status(200).json(user);
  } catch (error) {
    next(error);
    console.log(error);
  }
};
exports.getUserProfile = async (req, res, next) => {
  try {
    const user = await userService.getUserProfile(Number(req.params.id));
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    delete user.password;
    delete user.email;
    delete user.passwordResetToken;
    delete user.emailVerificationToken;
    delete user.emailVerified;
    delete user.createdAt;
    delete user.updatedAt;
    delete user.deletedAt;
    delete user.role;
    delete user.subscription;
    delete user.subscriptionId;
    delete user.image
    res.status(200).json(user);
  } catch (error) {
    next(error);
    console.log(error);
  }
};


exports.updateUser = async (req, res, next) => {
  try {
    const { pseudo, description } = req.body;
    const updatedUser = await userService.updateUser(req.user.id, { pseudo, description });
    res.status(200).json(updatedUser);
  } catch (error) {
    next(error);
    console.log(error);
  }
};

exports.uploadPicture = async (req, res, next) => {
  try {

    if (!req.file) {
      return res.status(403).send('Aucun fichier téléchargé');
    }

     const profilePicture =""// await uploadProfilePicture(req.user.id, req.file.path);
    res.status(200).send({ message: 'Fichier téléchargé avec succès', profilePicture });

  } catch (error) {
    next(error);
    console.log(error);
  }
}

exports.getProfilePicture = async (req, res, next) => {
  try {
    const picture ="" //await getProfilePicture(req.user.id);
    res.status(200).send(picture);
  } catch (error) {
    next(error);
    console.log(error);
  }
}

exports.deleteUser = async (req, res, next) => {
  try {
    const deletedUser = await userService.deleteUser(req.user.id);
    res.status(200).json(deletedUser);
  } catch (error) {
    next(error);
    console.log(error);
  }
};

exports.resetPassword = async (req, res, next) => {
  try {
    await userService.resetPassword(req.body.email, req.body.newPassword);
    res.status(200).json({ message: 'Password reset successfully' });
  } catch (error) {
    next(error);
    console.log(error);
  }
};


// ...



///requestEmailVerification
exports.requestEmailVerification = async (req, res, next) => {
  try {
    const verifyUrl = `${process.env.CLIENT_URL}/signin/verification/email?token=${token}`;
    const token = await authService.createEmailVerificationToken(req.body.email);

    const setup = [
      { key: '#firstName#', value: firstName },
      { key: '#verificationUrl#', value: verifyUrl },
    ];

    const content = await sendFormatedTemplate('welcome', setup, email, 'Verifiez votre email');
    res.status(200).json({ message: 'Email verification link sent to email' });
  } catch (error) {
    next(error);
    console.log(error);
  }
}




//STATS

exports.getUserWithStats = async (req, res, next) => {
  try {
    const userId = req.params.userId;
    const user = await getUserWithStats(userId);

    res.status(200).json(user);
  } catch (error) {
    next(error);
    console.log(error);
  }
}


exports.getAllUsers = async (req, res, next) => {
  try {
    const users = await userService.getAllUsers();
    res.status(200).json(users);
  } catch (error) {
    next(error);
    console.log(error);
  }
}



exports.uploadProfilePicture = async (req, res, next) => {
  try {
    const profilePictureUrl = req.file.filename;

    await userService.uploadProfilePicture(req.user.id, profilePictureUrl);


    res.status(200).json({ message: 'Profile picture uploaded successfully', profilePictureUrl });
  } catch (error) {
    next(error);
    console.log(error);
  }
};

exports.deleteProfilePicture = async (req, res, next) => {
  try {
    const picture = userService.deleteProfilePicture(req.user.id);
    res.status(200).json({ message: 'Profile picture deleted successfully' });
  } catch (error) {
    next(error);
    console.log(error);
  }
}
