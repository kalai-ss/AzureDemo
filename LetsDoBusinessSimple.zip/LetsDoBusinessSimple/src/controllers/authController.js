const authService = require('../services/authService');
const { sendFormatedTemplate } = require('../utils/template');

exports.register = async (req, res, next) => {
  try {
    const newUser = await authService.register(req.body);
    req.body.newUser = newUser;
    res.status(201).json(newUser);
  } catch (error) {
    next(error);
    console.log(error);
  }
};

exports.login = async (req, res, next) => {
  try {
    const { token, user } = await authService.login(req.body);
    res.status(200).json({ token, user });
  } catch (error) {
    next(error);
    console.log(error);
  }
};

exports.verifyEmail = async (req, res, next) => {
  try {
    const user = await authService.verifyEmail(req.params.token);
    res.status(200).send({ message: 'Email verified successfully' });
  } catch (error) {
    next(error);
    console.log(error);
  }
}

exports.requestPasswordReset = async (req, res, next) => {
  try {
    const { email } = req.body;
    const { user, token } = await authService.createPasswordResetToken(email);
    const resetUrl = `${process.env.CLIENT_URL}/password/reset/${token}`;
    const data = [
      { key: '#firstName#', value: user.firstName },
      { key: '#resetUrl#', value: encodeURI(resetUrl) },
    ];

    const content = await sendFormatedTemplate('passwordReset', data, email, 'Bienvenue à bord !');

    res.status(200).json({ message: 'Password reset link sent to email' });
  } catch (error) {
    if (error.code === 202) {
      res.status(202).json({ message: '' })
    } else {
      next(error);
      console.log(error);
    }
  }
};


//resetPasswordWithToken
exports.resetPasswordWithToken = async (req, res, next) => {
  try {

    /// verify token time and user
    const token = await authService.verifyPasswordResetToken(req.body.token);
    const user = await authService.resetPasswordWithToken(req.body.token, req.body.password);
    res.status(200).json(user);
  } catch (error) {
    next(error);
    console.log(error);
  }
}

exports.verifyPasswordResetToken = async (req, res, next) => {
  try {
    const token = await authService.verifyPasswordResetToken(req.params.token);
    res.status(200).json({ message: 'Token verified successfully' });
  } catch (error) {
    next(error);
    console.log(error);
  }
}
