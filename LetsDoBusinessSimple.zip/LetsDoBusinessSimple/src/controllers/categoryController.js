// createCategory
// getAllCategories
// getCategoryById
// updateCategory
// deleteCategory

/// create CRUD operations for the category controller
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
const categoryService = require('../services/categoryService');

exports.createCategory = async (req, res, next) => {
    try {
        const data = req.body;
        const category  = await categoryService.createCategory(data);
        res.status(201).json(category);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.getAllCategories = async (req, res, next) => {
    try {
        
        const categories = await categoryService.getAllCategories();
        res.status(200).json(categories);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.getCategoryById = async (req, res, next) => {
    try {
        const id = parseInt(req.params.id)
        const category = await categoryService.getCategoryById(id);
        res.status(200).json(category);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.updateCategory = async (req, res, next) => {
    try {

        const data = req.body;
        const id = parseInt(req.params.id)
        const category = await categoryService.updateCategory(id, data);

        res.status(200).json(category);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

exports.deleteCategory = async (req, res, next) => {
    try {

        const id = parseInt(req.params.id)
        const category = await categoryService.deleteCategory(id);
        res.status(200).json(category);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
}

