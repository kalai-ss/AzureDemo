// createSubCategory
// getAllSubCategories
// getSubCategoryById
// updateSubCategory
// deleteSubCategory
// getSubCategoryByCategoryId
// getSubCategoryByCategoryName

/// create CRUD operations for the subCategory controller

const subCategoryService = require('../services/subCategoryService');

exports.createSubCategory = async (req, res, next) => {
    try {
        const data = req.body;
        const subCategory = await subCategoryService.createSubCategory(data);
        res.status(201).json(subCategory);
    } catch (error) {
        next(error)
    }
}

exports.getAllSubCategories = async (req, res, next) => {
    try {
        const subCategories = await subCategoryService.getAllSubCategories();
        res.status(200).json(subCategories);
    } catch (error) {
        next(error)
    }
}

exports.getSubCategoryById = async (req, res, next) => {
    try {
        const id = parseInt(req.params.id)
        const subCategory = await subCategoryService.getSubCategoryById(id);
        res.status(200).json(subCategory);
    } catch (error) {
        next(error)
    }
}

exports.updateSubCategory = async (req, res, next) => {
    try {
        const data = req.body;
        const id = parseInt(req.params.id)
        const subCategory = await subCategoryService.updateSubCategory(id, data);
        res.status(200).json(subCategory);
    } catch (error) {
        next(error)
    }
}

exports.deleteSubCategory = async (req, res, next) => {
    try {

        const id = parseInt(req.params.id)
        const subCategory = await subCategoryService.deleteSubCategory(id);

        res.status(200).json(subCategory);
    } catch (error) {
        next(error)
    }
}

exports.getSubCategoryByCategoryId = async (req, res, next) => {
    try {

        const id = parseInt(req.params.categoryId)
        const subCategory = await subCategoryService.getSubCategoryByCategoryId(id);        
        res.status(200).json(subCategory);
    } catch (error) {
        next(error)
    }
}

exports.getSubCategoryByCategoryName = async (req, res, next) => {
    try {
        const subCategory = await subCategoryService.getSubCategoryByCategoryName(req.params.categoryName);
        res.status(200).json(subCategory);
    } catch (error) {
        next(error)
    }
}
