

// CRUD operations for the product controller
const productService = require('../services/productService');

exports.createProduct = async (req, res, next) => {
    try {
        const data = req.body;
        const product = await productService.createProduct(data);
        res.status(201).json(product);
    } catch (error) {
        next(error)
    }
}

exports.getAllProducts = async (req, res, next) => {
    try {
        const products = await productService.getAllProducts();
        res.status(200).json(products);
    } catch (error) {
        next(error)
    }
}

exports.getProductById = async (req, res, next) => {
    try {
        const id = parseInt(req.params.id);
        const product = await productService.getProductById(id);
        res.status(200).json(product);
    } catch (error) {
        next(error)
    }
}

exports.updateProduct = async (req, res, next) => {
    try {
        const id = parseInt(req.params.id);
        const data = req.body;
        const product = await productService.updateProduct(id, data);
        res.status(200).json(product);
    } catch (error) {
        next(error)
    }
}

exports.deleteProduct = async (req, res, next) => {
    try {
        const id = parseInt(req.params.id);
        const product = await productService.deleteProduct(id);
        res.status(200).json(product);
    } catch (error) {
        next(error)
    }
}

exports.getProductByCategory = async (req, res, next) => {
    try {
        const id = parseInt(req.params.categoryId);
        const products = await productService.getProductByCategory(id);
        res.status(200).json(products);
    } catch (error) {
        next(error)
    }
}

exports.getProductBy = async (req, res, next) => {
    try {
        const where = req.params
        const products = await productService.getProductBy(where);
        res.status(200).json(products);
    } catch (error) {
        next(error)
    }
}
