/// test createAdressForUser in the file addressService.js


// Path: src\test\services\addressService.test.js

//createAdressForBooking
//getAllAdress
//getPostalAdress
//getAdressById
//updateAdress
//deleteAdress
//getAdressByUserId
//getAdressFromGeo
//getGeoFromAdress

///test all the functions in the file addressService.js
// Path: src\test\services\addressService.test.js

const addressService = require('../../services/addressService');
const userService = require('../../services/userService');
const bookingService = require('../../services/bookingService');

describe('addressService', () => {
    ///test add address for user
    describe('createAdressForUser', () => {
        it('should create an address for a user from a coordinates', async () => {
            const user = await userService.createUser({
                email: 'glucry+3@gmail.com',
            }
