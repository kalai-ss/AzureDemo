/// read the content of the repository ../../services
/// and create a list of all the files in the repository
/// and add .test.js to the end of the file name
/// and add the file name to the list
/// create yhose files in the repository ../test/services

const fs = require('fs');
const path = require('path');

const servicesPath = path.join(__dirname, '../../services');
const testServicesPath = path.join(__dirname, '../services');

const files = fs.readdirSync(servicesPath);
const testFiles = files.map((file) => {
    return file.replace('.js', '.test.js');
}
);

testFiles.forEach((file) => {
    fs.writeFileSync(path.join(testServicesPath, file), '');
}
);

