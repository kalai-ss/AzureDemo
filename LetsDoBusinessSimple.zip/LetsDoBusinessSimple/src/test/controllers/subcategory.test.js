const axios = require('axios');

describe('Subcategory Route', () => {
    it('should return subcategories', async () => {
        const response = await axios.get('/api/subcategories');
        expect(response.status).toBe(200);
        expect(response.data).toHaveProperty('subcategories');
        expect(Array.isArray(response.data.subcategories)).toBe(true);
    });

    it('should return a specific subcategory', async () => {
        const subcategoryId = '12345';
        const response = await axios.get(`/api/subcategories/${subcategoryId}`);
        expect(response.status).toBe(200);
        expect(response.data).toHaveProperty('subcategory');
        expect(response.data.subcategory.id).toBe(subcategoryId);
    });

    it('should create a new subcategory', async () => {
        const newSubcategory = {
            name: 'New Subcategory',
            description: 'This is a new subcategory',
        };
        const response = await axios.post('/api/subcategories', newSubcategory);
        expect(response.status).toBe(201);
        expect(response.data).toHaveProperty('subcategory');
        expect(response.data.subcategory.name).toBe(newSubcategory.name);
        expect(response.data.subcategory.description).toBe(newSubcategory.description);
    });

    it('should update an existing subcategory', async () => {
        const subcategoryId = '12345';
        const updatedSubcategory = {
            name: 'Updated Subcategory',
            description: 'This subcategory has been updated',
        };
        const response = await axios.put(`/api/subcategories/${subcategoryId}`, updatedSubcategory);
        expect(response.status).toBe(200);
        expect(response.data).toHaveProperty('subcategory');
        expect(response.data.subcategory.name).toBe(updatedSubcategory.name);
        expect(response.data.subcategory.description).toBe(updatedSubcategory.description);
    });

    it('should delete an existing subcategory', async () => {
        const subcategoryId = '12345';
        const response = await axios.delete(`/api/subcategories/${subcategoryId}`);
        expect(response.status).toBe(200);
        expect(response.data).toHaveProperty('message');
        expect(response.data.message).toBe('Subcategory deleted successfully');
    });
});
