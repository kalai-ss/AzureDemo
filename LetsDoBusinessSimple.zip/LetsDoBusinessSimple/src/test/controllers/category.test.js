const axios = require('axios');

// Test create category route

/*model Category {
  id          Int           @id @default(autoincrement())
  name        String
  description String?
  products    Product[]
  subCategory SubCategory[]
}
*/

const server = 'http://localhost:3000/api';
describe('POST /categories', () => {
    it('should create a new category', async () => {
        const categoryData = {
            name: 'Test Category',
            description: 'This is a test category',
        };
        const api_url = server + '/categories';
        const response = await axios.post(api_url, categoryData);

        expect(response.status).toBe(201);
        expect(response.data).toHaveProperty('id');
        expect(response.data.name).toBe(categoryData.name);
        expect(response.data.description).toBe(categoryData.description);
    });
});

// Test get category route
describe('GET /categories/:id', () => {
    it('should get a category by ID', async () => {
        const categoryId = '12345';
        const api_url = server + '/categories/' + categoryId;
        const response = await axios.get(api_url);

        expect(response.status).toBe(200);
        expect(response.data).toHaveProperty('id');
        expect(response.data).toHaveProperty('name');
        expect(response.data).toHaveProperty('description');
    });
});

// Test update category route
describe('PUT /categories/:id', () => {
    it('should update a category by ID', async () => {
        const categoryId = '12345';
        const updatedCategoryData = {
            name: 'Updated Category',
            description: 'This is an updated category',
        };
        const api_url = server + '/categories/' + categoryId;
        const response = await axios.put(api_url, updatedCategoryData);

        expect(response.status).toBe(200);
        expect(response.data).toHaveProperty('id');
        expect(response.data.name).toBe(updatedCategoryData.name);
        expect(response.data.description).toBe(updatedCategoryData.description);
    });
});

// Test delete category route
describe('DELETE /categories/:id', () => {
    it('should delete a category by ID', async () => {
        const categoryId = '12345';
        const api_url = server + '/categories/' + categoryId;
        const response = await axios.delete(api_url);

        expect(response.status).toBe(200);
        expect(response.data).toHaveProperty('message', 'Category deleted successfully');
    });
});
