/// tesr passwordRecover.js
const routes = require('../utils/apiUrls');
const apiRequest = routes.apiRequest;
const api = routes.api;

let clientToken;
let heroToken;
let heroId;
let activityId;
let bookingId;
let headers

describe('Scénarios de test', () => {
   

    test('Demande de reinitialisation de mot de passe ', async () => {
        let { url, baseURL } = api.user.postRequestResetPassword;
        const response = await apiRequest({
            url: baseURL + url, method: "post", data: {
                email: 'nouvelutilisateurneeder2@yopmail.com'
            }

        });

        
    });
   


   
});
