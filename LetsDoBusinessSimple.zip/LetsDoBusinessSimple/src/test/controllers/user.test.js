const {api , apiRequest} = require('../utils/apiUrls');


let clientToken;
let heroToken;
let activityId;
let bookingId;
let headers

describe('Scénarios de test', () => {
    test('Inscription utilisateur needer', async () => {
        let { url, baseURL } = api.auth.postRegister;
        const response = await apiRequest({
            url: baseURL + url, method: "post", data: {
                email: 'nouvelutilisateurneeder2@yopmail.com',
                password: 'MotDePasse123',
                firstName: 'John Wick',
                lastName: 'Doe',
            }
        });

        expect(response.status).toBe(201);
        expect(response.data).toHaveProperty('id');
        expect(response.data).toHaveProperty('role');

        clientToken = response.data.token;
    });
    test('Inscription utilisateur hero', async () => {
        let { url, baseURL } = api.auth.postRegister;
        const response = await apiRequest({
            url: baseURL + url, method: "post", data: {
                email: 'nouvelutilisateurhero2@yopmail.com',
                password: 'MotDePasse123',
                firstName: 'John Hero',
                lastName: 'Doe',
            }
        });

        expect(response.status).toBe(201);
        expect(response.data).toHaveProperty('id');
        expect(response.data).toHaveProperty('role');

        heroToken = response.data.token;
    });

    test('Connexion utilisateur needer', async () => {
        let { url, baseURL } = api.auth.postAuth;
        const response = await apiRequest({
            url: baseURL + url, method: "post", data: {
                email: 'nouvelutilisateurneeder2@yopmail.com',
                password: 'MotDePasse123',
            }
        });

        expect(response.status).toBe(200);
        expect(response.data).toHaveProperty('token');

        clientToken = response.data.token;
    });
    test('Connexion utilisateur hero', async () => {
        let { url, baseURL } = api.auth.postAuth;
        const response = await apiRequest({
            url: baseURL + url, method: "post", data: {
                email: 'nouvelutilisateurhero2@yopmail.com',
                password: 'MotDePasse123',
            }
        });

        expect(response.status).toBe(200);
        expect(response.data).toHaveProperty('token');

        heroToken = response.data.token;
    });

    test('Création d\'une activité', async () => {
        const { url, baseURL } = api.bookings.post;
        const response = await apiRequest({
            url: baseURL + url,
            method: 'post',
            data: {
                "title": "test",
                "description": "tata ti tatata TESTE TESTE ",
                "subcategoryId": 14,
                "startDate": "07/28/2023",
                "endDate": "07/29/2023",
                "latitude": 48.8046592,
                "longitude": 2.4182784,
                "heroNeeded": 1
            },
            config: {
                headers: {
                    Authorization: `Bearer ${clientToken}`,
                },
            },

        });
        expect(response.status).toBe(201);
        expect(response.data).toHaveProperty('id');
        bookingId = response.data.id;

    });


    test('Réservation d\'une activité', async () => {
        const { url, baseURL } = api.bookings.postSubscription;
        const URL = (baseURL + url).replace(':bookingId', bookingId);
        const response = await apiRequest({
            url: URL,
            method: 'post',
            config: {
                headers: {
                    Authorization: `Bearer ${heroToken}`,
                },
            },
        });

        expect(response.status).toBe(201);
        expect(response.data).toHaveProperty('bookingId');

        bookingId = response.data.bookingId;
    });

    test('Suppression d\'une réservation', async () => {
        const { url, baseURL } = api.bookings.delete;
        const URL = (baseURL + url).replace(':id', bookingId);

        const response = await apiRequest({
            url: URL,
            method: 'delete',
            config: {
                headers: {
                    Authorization: `Bearer ${clientToken}`,
                },
            },
        });
        console.log(response.data);
      
        expect(response.status).toBe(201);
        expect(response).toHaveProperty('data');

    });
});
