const axios = require('axios');

describe('Product Route', () => {
    it('should return a list of products', async () => {
        const response = await axios.get('/api/products');
        expect(response.status).toBe(200);
        expect(response.data).toBeDefined();
        expect(Array.isArray(response.data)).toBe(true);
    });

    it('should return a single product by ID', async () => {
        const productId = '12345'; // Replace with a valid product ID
        const response = await axios.get(`/api/products/${productId}`);
        expect(response.status).toBe(200);
        expect(response.data).toBeDefined();
        expect(response.data.id).toBe(productId);
    });

    it('should create a new product', async () => {
        const newProduct = {
            name: 'New Product',
            price: 9.99,
            category: 'Electronics',
        };

        const response = await axios.post('/api/products', newProduct);
        expect(response.status).toBe(201);
        expect(response.data).toBeDefined();
        expect(response.data.name).toBe(newProduct.name);
        expect(response.data.price).toBe(newProduct.price);
        expect(response.data.category).toBe(newProduct.category);
    });

    it('should update an existing product', async () => {
        const productId = '12345'; // Replace with a valid product ID
        const updatedProduct = {
            name: 'Updated Product',
            price: 19.99,
            category: 'Electronics',
        };

        const response = await axios.put(`/api/products/${productId}`, updatedProduct);
        expect(response.status).toBe(200);
        expect(response.data).toBeDefined();
        expect(response.data.id).toBe(productId);
        expect(response.data.name).toBe(updatedProduct.name);
        expect(response.data.price).toBe(updatedProduct.price);
        expect(response.data.category).toBe(updatedProduct.category);
    });

    it('should delete an existing product', async () => {
        const productId = '12345'; // Replace with a valid product ID
        const response = await axios.delete(`/api/products/${productId}`);
        expect(response.status).toBe(204);
    });
});
