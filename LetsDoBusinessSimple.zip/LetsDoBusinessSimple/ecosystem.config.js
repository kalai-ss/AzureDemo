module.exports = {
    apps: [
      {
        name: 'ldbs-app',
        script: 'src/index.js',
        instances: '1',
        exec_mode: 'cluster',
        env: {
          NODE_ENV: 'development',
        },
        env_production: {
          NODE_ENV: 'production',
          PORT: 2000,
          CLIENT_URL : "https://ldbs.fr",
          LANDING_URL : "https://welcome.ldbs.fr",
          DATABASE_URL: 'postgresql://master:L3z6nQX3M2dW53C4qk76VAz9tMMvn7fp@localhost:5432/ldbs?schema=public',
          JWT_SECRET: 'ui4rfvfcec874654ecldbs98735ac5e6rc51erc84cer32348vekeokoekcerkdkmlzked4444cz ',
          JWT_EXPIRES_IN: '2d',
          SMTP_HOST: "ssl0.ovh.net",
          SMTP_PORT: "587",
          SMTP_SECURE: "false",
          SMTP_USER: "contact@ldbs.fr",
          SMTP_PASS: "ldbsPsswrd!",
          SMTP_FROM: "contact@ldbs.fr",
          MAPBOX_API_KEY:"pk.eyJ1IjoiZ2x1Y3J5IiwiYSI6ImNqdGJudm5rdjBocWE0M3BmZHlxbmp3MXoifQ.nN5DiDoQHYDvxCPzyWcrSw",
          REACT_APP_BASEURL: "http://localhost:9000",
          
          
        },
      },
    ],
  };
  