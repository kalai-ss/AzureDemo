
-----------------------------------------------------------------------
Authentification LDBS
-----------------------------------------------------------------------
POST
Login
http://localhost:8000/api/auth/login



Body:
json
{
    "email" : "grolp2p@yopmail.com",
    "password" : "123456789!!pp"
}
 
-----------------------------------------------------------------------
POST
Create User
http://localhost:8000/api/auth/register



Body:
json
{
    "email" : "grols@yopmail.com",
    "password" : "123456pm",
    "firstName" : "Grego",
    "lastName" :"Luc"
}

-----------------------------------------------------------------------
POST
Request forgotten password
http://localhost:8000/api/auth/password/reset



Body:
json
{
    "email" :"grolp2p@yopmail.com"
}

-----------------------------------------------------------------------
POST
Register
http://localhost:8000/api/auth/register



Body:
json
{
    "email" : "grolp2p@yopmail.com",
    "password" : "123456pm",
    "firstName" : "Grego",
    "lastName" :"Luc"
}

-----------------------------------------------------------------------
POST
Verify email
http://localhost:8000/api/auth/verify-email/:token


Path Variables
token
d2e19c68-3738-4f7e-ace2-e29940866185

-----------------------------------------------------------------------
GET
Check reset password token
http://localhost:8000/api/auth/password/reset/:token


Path Variables
token
cb63145a-fffc-49e5-bc76-984fc7bfa74d

-----------------------------------------------------------------------
PUT
Set new password
http://localhost:8000/api/auth/password/reset/:token


Path Variables
token

Body:
json
{
    "token" : "cb63145a-fffc-49e5-bc76-984fc7bfa74d",
    "password" : "123456789!!pp"
}